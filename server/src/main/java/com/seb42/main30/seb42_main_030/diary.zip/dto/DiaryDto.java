package com.seb42.main30.seb42_main_030.diary.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

public class DiaryDto {

    @Getter
    @AllArgsConstructor
    public static class Post {

        @NotNull
        private String title;
        private String body;
        private String playlistId;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    public static class Patch {
        private long dairyId;

        @NotNull
        private String title;
        private String body;
    }

    @Getter
    @AllArgsConstructor
    public static class Response {
        private long dairyId;

        @NotNull
        private String title;
        private String body;
    }
}
