package com.seb42.main30.seb42_main_030.diary.controller;

import com.seb42.main30.seb42_main_030.diary.dto.DiaryDto;
import com.seb42.main30.seb42_main_030.diary.entity.Diary;
import com.seb42.main30.seb42_main_030.diary.mapper.DiaryMapper;
import com.seb42.main30.seb42_main_030.diary.service.DiaryService;
import com.seb42.main30.seb42_main_030.playlist.entity.Playlist;
import com.seb42.main30.seb42_main_030.user.entity.User;
import com.seb42.main30.seb42_main_030.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/diary")
public class DiaryDetailsController {

    private final DiaryService diaryService;
    private final DiaryMapper mapper;

    // 게시물 등록
    @PostMapping("")
    public ResponseEntity createDiary(@RequestBody DiaryDto.Post requestbody){
        Diary diary = mapper.diaryPostToDiary(requestbody);
        Diary createDiary = diaryService.createDiary(diary);

        return new ResponseEntity<>(new SingleResponseDto<>(
                mapper.diaryToDiaryResponse(createDiary)), HttpStatus.CREATED);
    }
    // 게시물 조회
    @GetMapping("/{diaryId}")
    @ResponseBody
                                    // @PathVariable URL변수
    public ResponseEntity findDiaryById(@PathVariable String diary_id){
        Diary diary = diaryService.findDiary(diary_id);

        return new ResponseEntity<>(new SingleREsponseDto<>(
                mapper.diaryToDiaryResponse() HttpStatus.OK)
    }


    @PatchMapping

}
