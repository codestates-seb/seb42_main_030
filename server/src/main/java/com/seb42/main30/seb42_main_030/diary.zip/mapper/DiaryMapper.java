package com.seb42.main30.seb42_main_030.diary.mapper;

import com.seb42.main30.seb42_main_030.diary.dto.DiaryDto;
import com.seb42.main30.seb42_main_030.diary.entity.Diary;
import org.mapstruct.Mapper;


import java.util.List;

@Mapper(componentModel = "spring")
public interface DiaryMapper {
    Diary diaryPostToDiary(DiaryDto.Post post);
    Diary diaryPatchToDiary(DiaryDto.Patch patch);
    DiaryDto.Response diaryToDiaryResponse(Diary diary);
    List<DiaryDto.Response> diaryToDiaryResponses(List<Diary> diary);

}
